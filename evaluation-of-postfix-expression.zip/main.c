/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include<conio.h>
#include<ctype.h>
#define n 10
int top=-1;
int arr[n];
//char postfix[20];
void push(int val)
{
    if(top==n-1)
    {
        printf("stack overflow\n");
        return ;
    }
    arr[++top]=val;
}
int pop()
{
    if(top==-1)
    {
        printf("Stack is empty");
        return 0;
    }
    int ele=arr[top];
    top--;
    return ele;
}
void display()
{
    for(int i=top;i>=0;i--)
    {
        printf("%d\t",arr[top]);
    }
}
int peep()
{
    if(top==-1)
    {
        printf("No element in stack");
        return -1;
    }
    return arr[top];
}
float compute(int a,int b,char ch)
{
    switch(ch)
    {
        case '+': return (a+b);
        case '-': return (a-b);
        case '*': return (a*b);
        case '/': return (a/b);
        default: printf("Not valid");
    }
    return 0;
}
void postfix_to_infix()
{
     printf("Enter postfix expression:");
    char postfix[9]="934*8+4/-";
    postfix[9]='\0';
    int res;
    int i=0;
    while(postfix[i]!='\0')
    {
        if(isdigit(postfix[i]))
        {
            push((int)postfix[i]-'0');
        }
        else{
            int val1=pop();
            int val2=pop();
            res=compute(val2,val1,postfix[i]);
            push(res);
        }
        i++;
        
    }
    printf("Result=%d",pop());
}

int main()
{
    
   
    postfix_to_infix();
}