/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<conio.h>

struct student{
	int id;
	int age;
	int marks;
}s[100];
void input_accept(int i)
{   printf("Enter the id-");
    scanf("%d",&s[i].id);
    printf("Enter the age-");
    scanf("%d",&s[i].age);
    printf("Enter the marks-");
    scanf("%d",&s[i].marks);
}
void check(int i)
{
	if(s[i].age>20 && s[i].marks>=0 && s[i].marks<=100)
	{ printf("student-%d Data is  valid:\n",i+1);
	  if(s[i].marks>=65){
	   printf("student-%d is qualified for admission\n",i+1);}
	}
	else{
	printf("Student-%d Data is not valid\n",i+1);}
}

void display(int i)
{
    printf("Student details are:\n");
    printf("ID-%d\t",s[i].id);
    printf("Age-%d\t",s[i].age);
    printf("marks-%d\n",s[i].marks);
   }


int main()
{
   // struct student s[100];
    int total_students,i;
    clrscr();
    printf("Enter the number of students-");
    scanf("%d",&total_students);
    for(i=0;i<total_students;i++)
    {
	input_accept(i);
    }
    for(i=0;i<total_students;i++)
    {
	display(i);
    }
    for(i=0;i<total_students;i++)
   {
	check(i);
	}
    getch();
    return 0;
}