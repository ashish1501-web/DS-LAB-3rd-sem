/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define n 10
int arr[n];
int top=-1;

void push(int val)
{
    arr[++top]=val;
}
int pop()
{
    return arr[top--];
}
int main()
{   int i=0,a,b,res=0;
    char postfix[50],ch;
    scanf("%s",postfix);
    while((ch=postfix[i++])!='\0')
    {
        if(ch>='1' && ch<='9')
        {
            push(ch-'0');
        }
        else{
            a=pop();
            b=pop();
            switch(ch)
            {
                case '+': res=b+a; break;
                case '-': res=b-a; break;
                case '*': res=b*a; break;
                case '/': res=b/a; break;
                case '^': res=b^a; break;
                default: break;
            }
            push(res);
        }
    }
    printf("%d",res);
}
    

